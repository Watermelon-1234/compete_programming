/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
int main()
{
    int a,b,c,d,e;
    for(a=1;a<=2000;a++)
    {
        for(b=1;b<=2000;b++)
        {
            for(c=1;c<=2000;c++)
            {
                for(d=1;d<=2000;d++)
                {
                    if(a*7+21==)
                }
            }
        }
    }
    return 0;
}

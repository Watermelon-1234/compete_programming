#include <iostream>

using namespace std;

int main()
{
    cout<<"2 500000";
    for(int i=0;i<500000;i++)
    {
        cout<<"1 10000"<<endl;
    }

    return 0;
}

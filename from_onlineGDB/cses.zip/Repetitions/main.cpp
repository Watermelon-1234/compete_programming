#include <iostream>
using namespace std;
int main()
{
    char a,pre_a='';
    int t=0,max;
    while(cin>>a)
    {
        if(pre_a=='')
        {
           pre_a=a;
           continue; 
        }
        if(pre_a==a)
        {
            t++;
        }
        else
        {
            t=0;
        }
        if(max>)
    }
}